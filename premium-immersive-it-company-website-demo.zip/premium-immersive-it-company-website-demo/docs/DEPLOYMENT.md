# Deployment Guide

## Fastest Deployment

### Netlify Drop

1. Visit `https://netlify.com/drop`
2. Drag `immersive-it-homepage-demo.html`
3. Copy the generated live URL

## GitHub Upload

Recommended files to upload:

- `immersive-it-homepage-demo.html`
- `README.md`
- `docs/PROJECT_OVERVIEW.md`
- `docs/DESIGN_DIRECTION.md`
- `docs/DEPLOYMENT.md`

## Why This Structure Helps

When a client opens the repository, this layout makes the project look organized, intentional, and professionally prepared rather than a single raw HTML file.
